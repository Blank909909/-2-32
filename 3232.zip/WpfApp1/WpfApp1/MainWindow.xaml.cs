﻿using System;
using System.Windows;
using System.Windows.Threading;
using System.Windows.Media;
using System.Windows.Shapes;
using System.Windows.Controls;

namespace EnergyConsumptionApp
{
    public partial class MainWindow : Window
    {
        private Random random = new Random();
        private DispatcherTimer timer;
        private double lastX = 0;
        private double lastY = 0;

        public MainWindow()
        {
            InitializeComponent();
            SetupTimer();
        }

        private void SetupTimer()
        {
            timer = new DispatcherTimer { Interval = TimeSpan.FromSeconds(1) };
            timer.Tick += Timer_Tick;
        }

        private void StartButton_Click(object sender, RoutedEventArgs e)
        {
            canvas.Children.Clear();
            lastX = 0;
            lastY = 0;
            timer.Start();
        }

        private void StopButton_Click(object sender, RoutedEventArgs e)
        {
            timer.Stop(); // Остановка таймера
        }

        private void Timer_Tick(object sender, EventArgs e)
        {
            if (IsWorkingHours())
            {
                double consumption = random.Next(20, 100);
                DrawGraph(consumption);
            }
        }

        private bool IsWorkingHours() => DateTime.Now.Hour >= 8 && DateTime.Now.Hour < 18;

        private void DrawGraph(double consumption)
        {
            double canvasHeight = canvas.ActualHeight;
            double canvasWidth = canvas.ActualWidth;

            double normalizedConsumption = (canvasHeight / 100) * consumption;
            double y = canvasHeight - normalizedConsumption;

            if (lastX == 0)
            {
                lastY = y;
                lastX += 10;
                return;
            }

            Line line = new Line
            {
                X1 = lastX - 10,
                Y1 = lastY,
                X2 = lastX,
                Y2 = y,
                Stroke = Brushes.Blue,
                StrokeThickness = 2
            };

            canvas.Children.Add(line);

            // Добавление текстового блока для отображения значения потребления
            TextBlock textBlock = new TextBlock
            {
                Text = $"{consumption} кВтч",
                Foreground = Brushes.Black,
                FontSize = 12,
                Margin = new Thickness(lastX + 5, y - 15, 0, 0) // Позиционирование текста рядом с точкой
            };

            canvas.Children.Add(textBlock); // Добавление текстового блока на канвас

            lastY = y;
            lastX += 10;

            if (lastX > canvasWidth)
            {
                lastX = 0;
                canvas.Children.Clear();
            }
        }
    }
}
